// TODO：將以下內容取代為您套用的 Firebase 專案配置

var firebaseConfig = {
  apiKey: "AIzaSyCbujMaNQH4-KIuNbSglH2SriVqvvRRa1g",
  authDomain: "test-445dbleisurepace-a3d51.firebaseapp.com",
  databaseURL: "https://leisurepace-a3d51-default-rtdb.firebaseio.com/",
  projectId: "leisurepace-a3d51",
  storageBucket: "gs://leisurepace-a3d51.appspot.com/",
};



//  初始化 Firebase
firebase.initializeApp(firebaseConfig);


